const API_BASE = '/api/v1';

export async function listThreads(params?: {
  softwareId?: string;
  category?: string;
  isResolved?: boolean;
  search?: string;
  page?: number;
  pageSize?: number;
}) {
  const query = new URLSearchParams();
  if (params?.softwareId) query.set('softwareId', params.softwareId);
  if (params?.category) query.set('category', params.category);
  if (params?.isResolved !== undefined) query.set('isResolved', String(params.isResolved));
  if (params?.search) query.set('search', params.search);
  if (params?.page) query.set('page', String(params.page));
  if (params?.pageSize) query.set('pageSize', String(params.pageSize));

  const res = await fetch(`${API_BASE}/community/threads?${query.toString()}`);
  return res.json();
}

export async function getThread(id: string) {
  const res = await fetch(`${API_BASE}/community/threads/${id}`);
  return res.json();
}

export async function createThread(data: {
  softwareId?: string;
  title: string;
  content: string;
  category?: string;
}) {
  const res = await fetch(`${API_BASE}/community/threads`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function createPost(threadId: string, data: { parentPostId?: string; content: string }) {
  const res = await fetch(`${API_BASE}/community/threads/${threadId}/posts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function reportContent(data: { threadId?: string; postId?: string; reason: string }) {
  const res = await fetch(`${API_BASE}/community/reports`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}
