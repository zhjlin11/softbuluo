import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  MessageSquare,
  ArrowLeft,
  CheckCircle2,
  Clock,
  Eye,
  Send,
  Flag,
  ShieldCheck,
  Package,
  Loader2,
  AlertCircle
} from 'lucide-react';
import { getThread, createPost, reportContent } from '../services/communityService';

export const CommunityDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [thread, setThread] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [replyContent, setReplyContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const loadData = () => {
    if (!id) return;
    setIsLoading(true);
    getThread(id)
      .then((res) => {
        if (res.success) setThread(res.data);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    loadData();
  }, [id]);

  const handleReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyContent.trim() || !id) return;
    setIsSubmitting(true);

    try {
      const res = await createPost(id, { content: replyContent });
      if (res.success) {
        setReplyContent('');
        setFeedback('回复已成功发表！');
        loadData();
      } else {
        alert(res.error?.message || '发表回复失败，请先登录会员账号');
      }
    } catch (err: any) {
      alert(err.message || '网络连接异常');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReport = async (postId?: string) => {
    const reason = prompt('请输入举报违规原因 (例如广告引流、恶意攻击、侵权等):', '广告营销或恶意引流');
    if (!reason) return;

    try {
      const res = await reportContent({
        threadId: !postId ? id : undefined,
        postId: postId || undefined,
        reason,
      });
      if (res.success) {
        alert('举报已成功提交至后台审核队列，感谢维护纯净社区！');
      }
    } catch (err: any) {
      alert(err.message);
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-[1000px] mx-auto px-4 py-24 text-center text-slate-400">
        <Loader2 className="w-8 h-8 animate-spin mx-auto text-[#1769D2] mb-3" />
        <span className="text-xs">加载讨论内容中...</span>
      </div>
    );
  }

  if (!thread) {
    return (
      <div className="max-w-[600px] mx-auto px-4 py-24 text-center">
        <h1 className="text-lg font-bold mb-2">讨论主题不存在或已关闭</h1>
        <Link to="/community" className="text-xs text-blue-600 hover:underline">
          返回社区讨论区
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-[1000px] mx-auto px-4 py-8">
      <Link
        to="/community"
        className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 mb-6"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>返回社区交流主页</span>
      </Link>

      {feedback && (
        <div className="p-3 mb-6 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs text-emerald-800 dark:text-emerald-300 flex items-center justify-between">
          <span>{feedback}</span>
          <button onClick={() => setFeedback(null)}>×</button>
        </div>
      )}

      {/* 主帖正文卡片 */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xs mb-6">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 bg-blue-50 dark:bg-blue-950/40 text-blue-600 text-xs font-semibold rounded">
              {thread.category}
            </span>
            {thread.isResolved && (
              <span className="inline-flex items-center gap-0.5 px-2 py-0.5 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>已解决</span>
              </span>
            )}
            {thread.software && (
              <Link
                to={`/software/${thread.software.slug}`}
                className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:text-blue-600 text-xs font-medium rounded transition-colors"
              >
                <Package className="w-3.5 h-3.5 text-blue-500" />
                <span>{thread.software.name}</span>
              </Link>
            )}
          </div>

          <button
            onClick={() => handleReport()}
            className="inline-flex items-center gap-1 text-[11px] text-slate-400 hover:text-rose-500 cursor-pointer"
          >
            <Flag className="w-3 h-3" />
            <span>举报违规</span>
          </button>
        </div>

        <h1 className="text-lg sm:text-2xl font-bold text-slate-900 dark:text-white mb-3">{thread.title}</h1>

        <div className="flex items-center gap-3 text-xs text-slate-400 mb-6">
          <span className="font-semibold text-slate-700 dark:text-slate-300">{thread.user?.username}</span>
          <span>·</span>
          <span>发布于 {new Date(thread.createdAt).toLocaleString()}</span>
          <span>·</span>
          <span className="inline-flex items-center gap-1">
            <Eye className="w-3.5 h-3.5" />
            <span>{thread.viewCount} 次浏览</span>
          </span>
        </div>

        <div className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">
          {thread.content}
        </div>
      </div>

      {/* 回复列表 */}
      <div className="space-y-4 mb-8">
        <h3 className="font-bold text-sm text-slate-800 dark:text-slate-200">
          回复交流 ({thread.posts?.length || 0})
        </h3>

        {thread.posts && thread.posts.length > 0 ? (
          thread.posts.map((post: any, index: number) => (
            <div
              key={post.id}
              className={`p-5 rounded-2xl border transition-all ${
                post.isDeveloperReply
                  ? 'bg-blue-50/50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900/50'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between gap-3 mb-2.5">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-xs text-slate-800 dark:text-slate-200">
                    {post.user?.username}
                  </span>

                  {/* 官方已认证开发者专属回复徽章 */}
                  {post.isDeveloperReply && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-600 text-white rounded-full text-[10px] font-bold shadow-2xs">
                      <ShieldCheck className="w-3 h-3" />
                      <span>官方认证开发者回复</span>
                    </span>
                  )}

                  <span className="text-[11px] text-slate-400">
                    #{index + 1} 楼 · {new Date(post.createdAt).toLocaleString()}
                  </span>
                </div>

                <button
                  onClick={() => handleReport(post.id)}
                  className="text-slate-300 hover:text-rose-500 p-1"
                >
                  <Flag className="w-3 h-3" />
                </button>
              </div>

              <div className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                {post.content}
              </div>
            </div>
          ))
        ) : (
          <div className="p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-center text-xs text-slate-400">
            暂无回复，发表您的看法或解决方案吧！
          </div>
        )}
      </div>

      {/* 发表回复框 */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-2xs">
        <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200 mb-2">发表您的回复</h4>
        <form onSubmit={handleReply} className="space-y-3">
          <textarea
            rows={3}
            required
            value={replyContent}
            onChange={(e) => setReplyContent(e.target.value)}
            placeholder="友好交流、理性探讨，禁止灌水推广与违法言论..."
            className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none"
          />
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-slate-400">系统已启用反广告与 XSS 自动化安全防护</span>
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-1.5 px-5 py-2 bg-[#1769D2] hover:bg-[#1258B5] text-white text-xs font-semibold rounded-xl cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              <span>发表回复</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
