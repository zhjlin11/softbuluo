import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  MessageSquare,
  Plus,
  Search,
  CheckCircle2,
  HelpCircle,
  Wrench,
  Sparkles,
  Pin,
  Clock,
  Eye,
  MessageCircle,
  Filter,
  X,
  AlertCircle,
  Loader2,
  Package
} from 'lucide-react';
import { listThreads, createThread } from '../services/communityService';

export const CommunityPage: React.FC = () => {
  const [threads, setThreads] = useState<any[]>([]);
  const [pagination, setPagination] = useState<any>({ page: 1, total: 0 });
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // 发帖表单
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    category: 'EXPERIENCE',
    softwareId: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const loadThreads = () => {
    setIsLoading(true);
    listThreads({
      category: selectedCategory || undefined,
      search: searchQuery || undefined,
      page: pagination.page,
    })
      .then((res) => {
        if (res.success) {
          setThreads(res.data);
          setPagination(res.pagination);
        }
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    loadThreads();
  }, [selectedCategory, pagination.page]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadThreads();
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setIsSubmitting(true);

    try {
      const res = await createThread({
        title: formData.title,
        content: formData.content,
        category: formData.category,
        softwareId: formData.softwareId.trim() || undefined,
      });

      if (res.success) {
        setIsModalOpen(false);
        setFormData({ title: '', content: '', category: 'EXPERIENCE', softwareId: '' });
        setFeedback('讨论已成功发起！');
        loadThreads();
      } else {
        setFormError(res.error?.message || '发起讨论失败，请检查是否已登录会员账号');
      }
    } catch (err: any) {
      setFormError(err.message || '网络请求异常');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getCategoryBadge = (cat: string) => {
    switch (cat) {
      case 'INSTALL_ISSUE':
        return <span className="px-2 py-0.5 bg-rose-50 dark:bg-rose-950/40 text-rose-600 rounded text-[10px]">安装排障</span>;
      case 'QUESTION':
        return <span className="px-2 py-0.5 bg-amber-50 dark:bg-amber-950/40 text-amber-600 rounded text-[10px]">使用问答</span>;
      case 'FEEDBACK':
        return <span className="px-2 py-0.5 bg-purple-50 dark:bg-purple-950/40 text-purple-600 rounded text-[10px]">功能建议</span>;
      default:
        return <span className="px-2 py-0.5 bg-blue-50 dark:bg-blue-950/40 text-blue-600 rounded text-[10px]">使用心得</span>;
    }
  };

  return (
    <div className="max-w-[1200px] mx-auto px-4 py-8">
      {/* 头部 Hero */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-[#1769D2]" />
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              软游部落用户社区与经验交流
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            真实用户的使用心得、疑难杂症排障与官方作者答疑互动，杜绝虚假机器人刷帖
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-[#1769D2] hover:bg-[#1258B5] text-white rounded-xl text-xs font-semibold shadow-2xs transition-all cursor-pointer whitespace-nowrap"
        >
          <Plus className="w-4 h-4" />
          <span>发起新讨论</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 mb-6 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs text-emerald-800 dark:text-emerald-300 flex items-center justify-between">
          <span>{feedback}</span>
          <button onClick={() => setFeedback(null)}>×</button>
        </div>
      )}

      {/* 分类标签栏与搜索 */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-6">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setSelectedCategory('')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              selectedCategory === ''
                ? 'bg-[#1769D2] text-white'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
            }`}
          >
            全部板块
          </button>
          <button
            onClick={() => setSelectedCategory('EXPERIENCE')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              selectedCategory === 'EXPERIENCE'
                ? 'bg-[#1769D2] text-white'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
            }`}
          >
            使用心得
          </button>
          <button
            onClick={() => setSelectedCategory('INSTALL_ISSUE')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              selectedCategory === 'INSTALL_ISSUE'
                ? 'bg-[#1769D2] text-white'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
            }`}
          >
            安装排障
          </button>
          <button
            onClick={() => setSelectedCategory('QUESTION')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              selectedCategory === 'QUESTION'
                ? 'bg-[#1769D2] text-white'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
            }`}
          >
            使用问答
          </button>
          <button
            onClick={() => setSelectedCategory('FEEDBACK')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              selectedCategory === 'FEEDBACK'
                ? 'bg-[#1769D2] text-white'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
            }`}
          >
            功能建议
          </button>
        </div>

        <form onSubmit={handleSearch} className="flex items-center gap-2">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="搜索讨论主题..."
            className="w-full sm:w-60 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs focus:outline-none"
          />
          <button
            type="submit"
            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-lg text-xs text-slate-700 dark:text-slate-300 font-medium cursor-pointer"
          >
            搜索
          </button>
        </form>
      </div>

      {/* 帖子列表 */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xs divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden">
        {isLoading ? (
          <div className="p-12 text-center text-slate-400">
            <Loader2 className="w-7 h-7 animate-spin mx-auto text-blue-600 mb-2" />
            <span className="text-xs">加载社区讨论中...</span>
          </div>
        ) : threads.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs">
            该分类下暂无讨论，点击右上角“发起新讨论”发布第一篇心得吧！
          </div>
        ) : (
          threads.map((t) => (
            <div
              key={t.id}
              className="p-4 sm:p-5 hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-all flex items-start justify-between gap-4"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                  {t.isPinned && (
                    <span className="inline-flex items-center gap-0.5 px-2 py-0.5 bg-rose-50 text-rose-600 rounded text-[10px] font-bold">
                      <Pin className="w-3 h-3" />
                      <span>置顶</span>
                    </span>
                  )}
                  {getCategoryBadge(t.category)}
                  {t.isResolved && (
                    <span className="inline-flex items-center gap-0.5 px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded text-[10px] font-semibold">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>已解决</span>
                    </span>
                  )}
                  {t.software && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded text-[10px]">
                      <Package className="w-3 h-3 text-blue-500" />
                      <span>{t.software.name}</span>
                    </span>
                  )}
                </div>

                <Link
                  to={`/community/thread/${t.id}`}
                  className="font-bold text-sm sm:text-base text-slate-900 dark:text-white hover:text-[#1769D2] dark:hover:text-blue-400 transition-colors line-clamp-1"
                >
                  {t.title}
                </Link>

                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">{t.content}</p>

                <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-2.5">
                  <span className="font-medium text-slate-600 dark:text-slate-300">
                    {t.user?.username || '用户'}
                  </span>
                  <span>·</span>
                  <span className="inline-flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{new Date(t.createdAt).toLocaleDateString()}</span>
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3 text-slate-400 text-xs shrink-0 self-center">
                <span className="inline-flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5" />
                  <span>{t.viewCount}</span>
                </span>
                <span className="inline-flex items-center gap-1 font-semibold text-blue-600">
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>{t.replyCount}</span>
                </span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* 发帖弹窗 */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">发起社区新讨论</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="p-3 mb-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleCreate} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">讨论板块 *</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                >
                  <option value="EXPERIENCE">使用心得与技巧</option>
                  <option value="INSTALL_ISSUE">安装与系统排障</option>
                  <option value="QUESTION">使用疑问求解</option>
                  <option value="FEEDBACK">功能与体验建议</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  讨论标题 * (5-120 字)
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="清晰简明描述您的问题或分享要点..."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  关联软件 ID (可选)
                </label>
                <input
                  type="text"
                  value={formData.softwareId}
                  onChange={(e) => setFormData({ ...formData, softwareId: e.target.value })}
                  placeholder="例如输入软件 ID，可在该软件详情页联动展示"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  详细内容 * (支持纯文本，系统已启用 XSS 防护)
                </label>
                <textarea
                  rows={5}
                  required
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  placeholder="详细描述系统环境、错误提示或具体操作步骤..."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-slate-500 hover:bg-slate-100 rounded-xl"
                >
                  取消
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-[#1769D2] hover:bg-[#1258B5] text-white font-semibold rounded-xl disabled:opacity-50"
                >
                  {isSubmitting ? '发布中...' : '立即发布讨论'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
